These models are not generally redistributable under the terms of Assimp's BSD license. Usually, an additional requirement on the use of the data is imposed (i.e. no commercial use, need credits, some creative commons variants, ...).

So, if you re-package Assimp for use in a 'clean' OSS package, consider removing this directory.

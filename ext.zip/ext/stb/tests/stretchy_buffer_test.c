#include "stretchy_buffer.h"

void test_sb(void)
{
   char *x = NULL;
   sb_push(x, 'x');
}